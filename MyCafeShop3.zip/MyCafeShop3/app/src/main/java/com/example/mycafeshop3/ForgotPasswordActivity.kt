package com.example.mycafeshop3

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class ForgotPasswordActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forgot_password)

        val registertextView = findViewById<TextView>(R.id.R_Register)
        registertextView.setOnClickListener{
            val registerIntent= Intent(this,SignUpActivity::class.java)
            startActivity(registerIntent)
        }

    }

}