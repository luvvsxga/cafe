package com.example.mycafeshop3

import android.os.Bundle
import android.content.Intent
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase


class MainActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val firebase: DatabaseReference = FirebaseDatabase.getInstance().getReference()

        val forgottextView = findViewById<TextView>(R.id.Forgot_Password)
        forgottextView.setOnClickListener{
           val forgotIntent=Intent(this,ForgotPasswordActivity::class.java)
            startActivity(forgotIntent)
        }
        val registertextView = findViewById<TextView>(R.id.R_Register)
        registertextView.setOnClickListener{
            val registerIntent=Intent(this,SignUpActivity::class.java)
            startActivity(registerIntent)
        }
        val btnSignIn = findViewById<Button>(R.id.btn_SignIn)
        btnSignIn.setOnClickListener{
            val SignInintent= Intent(this,MenuActivity::class.java)
            startActivity(SignInintent)

        }









    }


}

