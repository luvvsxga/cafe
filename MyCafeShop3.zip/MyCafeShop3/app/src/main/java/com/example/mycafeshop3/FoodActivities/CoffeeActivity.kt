package com.example.mycafeshop3.FoodActivities

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import com.example.mycafeshop3.MenuActivity
import com.example.mycafeshop3.R

class CoffeeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_coffee)

        val btnMainMenu = findViewById<Button>(R.id.CoffeeMainMenu)
        btnMainMenu.setOnClickListener{
            val MainMenuintent= Intent(this, MenuActivity::class.java)
            startActivity(MainMenuintent)

        }
    }
}