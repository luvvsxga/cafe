package com.example.mycafeshop3.FoodActivities

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import com.example.mycafeshop3.MenuActivity
import com.example.mycafeshop3.R

class sandwichActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sandwich)

        val btnMainMenu = findViewById<Button>(R.id.SandwichMainMenu)
        btnMainMenu.setOnClickListener{
            val MainMenuintent= Intent(this, MenuActivity::class.java)
            startActivity(MainMenuintent)

        }

    }
}