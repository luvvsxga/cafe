package com.example.myapplicationimat3911cw.model

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.google.firebase.Firebase


/* Database Config*/
private val DataBaseName = "CourseWorkDB.db"
private val ver : Int = 1





class DBHelper(context: Context) : SQLiteOpenHelper(context,DataBaseName,null ,ver) {

    /* Customer Table */
    private val CustomerTableName = "TCustomer"
    private val Customer_Column_ID = "CusId"
    private val Customer_Column_FullName = "CusFullName"
    private val Customer_Column_Email = "CusEmail"
    private val Customer_Column_PhoneNo = "CusPhoneNo"
    private val Customer_Column_UserName = "CusUserName"
    private val Customer_Column_Password = "CusPassword"
    private val Customer_Column_IsActive = "CusIsActive"

    /* Admin Table */
    private val AdminTableName = "TAdmin"
    private val Admin_Column_ID = "AdminId"
    private val Admin_Column_FullName = "AdminFullName"
    private val Admin_Column_Email = "AdminEmail"
    private val Admin_Column_PhoneNo = "AdminPhoneNo"
    private val Admin_Column_UserName = "AdminUserName"
    private val Admin_Column_Password = "AdminPassword"
    private val Admin_Column_IsActive = "AdminIsActive"


        // ..............................................................................
    // This is called the first time a database is accessed
    // Create a new database if not exist
    override fun onCreate(db: SQLiteDatabase?) {

        // Create Customer table
        var sqlCreateStatement: String = "CREATE TABLE $CustomerTableName ( $Customer_Column_ID INTEGER PRIMARY KEY AUTOINCREMENT, $Customer_Column_FullName TEXT NOT NULL, " +
                                         " $Customer_Column_Email TEXT NOT NULL, $Customer_Column_PhoneNo TEXT NOT NULL, $Customer_Column_UserName TEXT NOT NULL, " +
                                         " $Customer_Column_Password TEXT NOT NULL, $Customer_Column_IsActive INTEGER NOT NULL )"

        db?.execSQL(sqlCreateStatement)







//..........................................................
        //Create Admin table
        sqlCreateStatement = "CREATE TABLE $AdminTableName ( $Admin_Column_ID INTEGER PRIMARY KEY AUTOINCREMENT, $Admin_Column_FullName TEXT NOT NULL, " +
                " $Admin_Column_Email TEXT NOT NULL, $Admin_Column_PhoneNo TEXT NOT NULL, $Admin_Column_UserName TEXT NOT NULL, " +
                " $Admin_Column_Password TEXT NOT NULL, $Admin_Column_IsActive INTEGER NOT NULL )"

        db?.execSQL(sqlCreateStatement)
//..........................................................
//     Create other tables here
    }

    // This is called if the database ver. is changed
    override fun onUpgrade(p0: SQLiteDatabase?, p1: Int, p2: Int) {
        //TODO("Not yet implemented")
    }
//..........................................................
    // other functions


    

}