package com.example.mycafeshop3

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.example.mycafeshop3.databinding.ActivitySignUpBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase



class SignUpActivity : AppCompatActivity() {

    lateinit var enterEmail: EditText
    lateinit var enterUsername: EditText
    lateinit var enterPassword1: EditText
    lateinit var phonenum: EditText
    lateinit var btnSignUp: Button



    private lateinit var dbRef: DatabaseReference
    private lateinit var firebaseAuth: FirebaseAuth
    private lateinit var binding: ActivitySignUpBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_up)



        val goHometextView = findViewById<TextView>(R.id.GoHome)
        goHometextView.setOnClickListener {
            val gohomeIntent = Intent(this, MainActivity::class.java)
            startActivity(gohomeIntent)
        }

        var errorMessage: String?

        binding = ActivitySignUpBinding.inflate(layoutInflater)
        setContentView(binding.root)

        firebaseAuth = FirebaseAuth.getInstance()

        enterEmail = findViewById(R.id.EnterEmail)
        enterUsername = findViewById(R.id.EnterUsername)
        enterPassword1 = findViewById(R.id.EnterPassword1)
        phonenum = findViewById(R.id.phonenumber)
        btnSignUp = findViewById(R.id.btn_SignUp)

        dbRef = FirebaseDatabase.getInstance().getReference("customer")
        btnSignUp.setOnClickListener {
            //saveSignUp()
        }



            // making values to mu edit text


            fun saveSignUp(view: View) {


                val enterEmail = enterEmail.text.toString()
                val enterUsername = enterUsername.text.toString()
                val enterPassword1 = enterPassword1.text.toString()
                val phonenum = phonenum.text.toString()




                if (enterEmail.isEmpty()) {
                    errorMessage = "Please enter your Email"
                    Toast.makeText(this, errorMessage, Toast.LENGTH_LONG).show()


                }
                if (enterUsername.isEmpty()) {
                    errorMessage = "Please enter a Username"
                    Toast.makeText(this, errorMessage, Toast.LENGTH_LONG).show()


                }
                if (enterPassword1.isEmpty()) {
                    errorMessage = "Please enter a password"
                    Toast.makeText(this, errorMessage, Toast.LENGTH_LONG).show()

                }
                if (phonenum.isEmpty()) {
                    errorMessage = "Please enter your Phone Number"
                    Toast.makeText(this, errorMessage, Toast.LENGTH_LONG).show()

                }


            }
        }




    }

//    private fun saveSignUp() {
//        TODO("Not yet implemented")
//    }
