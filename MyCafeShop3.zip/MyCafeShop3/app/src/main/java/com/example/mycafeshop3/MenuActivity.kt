package com.example.mycafeshop3

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import com.example.mycafeshop3.FoodActivities.CoffeeActivity
import com.example.mycafeshop3.FoodActivities.sandwichActivity

class MenuActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu)

        val sandwichtextView = findViewById<TextView>(R.id.sandwich)
        sandwichtextView.setOnClickListener{
            val sandwichIntent=Intent(this, sandwichActivity::class.java)
            startActivity(sandwichIntent)
        }
        val coffeetextView = findViewById<TextView>(R.id.Coffee_txt)
        coffeetextView.setOnClickListener{
            val coffeeIntent=Intent(this, CoffeeActivity::class.java)
            startActivity(coffeeIntent)
        }
    }




}